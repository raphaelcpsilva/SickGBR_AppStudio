-- Declaração de variáveis para função de coleta de dados estatísticos
local tabelaDados1 = {}                           -- Tabela de apresentação das medições obtidas após cálculos
local tabelaDados2 = {}                           -- Tabela de apresentação das medições obtidas após cálculos
local auxProgresso1 = 0                           -- Auxiliar contador de ciclos para barra de progresso tab1
local auxProgresso2 = 0                           -- Auxiliar contador de ciclos para barra de progresso tab2
local totalMedidas = Parameters.get("qtdLinhas")  -- Total de medidas a serem apresentadas

-- Chamada do script de conversão da tabela para enviar para UI
local json = require("json")

--WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
-- Botão para limpar tabela na tela
function LimpaTabela()
  print("botão limpa tabela")
  
  auxProgresso1 = 0                           -- Auxiliar contador de ciclos para barra de progresso tab1
  auxProgresso2 = 0                           -- Auxiliar contador de ciclos para barra de progresso tab2
  Parameters.set("ProgressCam1", 0)           -- Limpa barra de progresso da coleta das medições
  Parameters.set("ProgressCam2", 0)           -- Limpa barra de progresso da coleta das medições

  tabelaDados1 = {}                               -- Limpa tabela de apresentação das medições
  tabelaDados2 = {}                               -- Limpa tabela de apresentação das medições
  
  local tabelaJson1 = json.encode(tabelaDados1)   -- Converte a tabela em mensagem 'string' para apresentação na tabela do UI
  local tabelaJson2 = json.encode(tabelaDados2)   -- Converte a tabela em mensagem 'string' para apresentação na tabela do UI

  Script.notifyEvent("enviaDado1", tabelaJson1)    -- Envia valores para tabela da UI
  Script.notifyEvent("enviaDado2", tabelaJson2)    -- Envia valores para tabela da UI
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.Butt_LimpaTabela", "LimpaTabela")
--WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW

--WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
--@functionname(p1:type):returnType
function registraNaTabela1(var1, var2, var3)
  -- Calcula progresso dos dados coletados
  auxProgresso1 = auxProgresso1 + 1                               -- Incrementa contador geral de progresso
  if auxProgresso1 >= totalMedidas then                           -- Mantém limite máximo na contagem
    auxProgresso1 = totalMedidas
  end

  local progressColetaDados1 = math.ceil((auxProgresso1 / totalMedidas) * 100)    -- Porcentagem do progresso de coleta de dados
  Parameters.set("ProgressCam1", progressColetaDados1)

  -- Monta tabela para atualizar valores na tabela da tela de visualização
  table.insert(tabelaDados1, 1, {diaTab1=DateTime.getDateTime(), var1Tab1=var1, var2Tab1=var2, var3Tab1=var3})

  -- Controla tamanho máximo da tabela
  if #tabelaDados1 > totalMedidas then
    for j=totalMedidas, #tabelaDados1 do
      table.remove(tabelaDados1, totalMedidas+1)
    end
  end

  local tabelaJson1 = json.encode(tabelaDados1)   -- Converte a tabela em mensagem 'string' para apresentação na tabela do UI
  Script.notifyEvent("enviaDado1", tabelaJson1)
end
Script.serveEvent("SIM_GenericViewer_TCPIPServer.enviaDado1", "enviaDado1")
Script.register("SIM_GenericViewer_TCPIPServer.AtualizaTabela1", registraNaTabela1)
--WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW

--WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
--@functionname(p1:type):returnType
function registraNaTabela2(var1, var2, var3)
  -- Calcula progresso dos dados coletados
  auxProgresso2 = auxProgresso2 + 1                               -- Incrementa contador geral de progresso
  if auxProgresso2 >= totalMedidas then                          -- Mantém limite máximo na contagem
    auxProgresso2 = totalMedidas
  end

  local progressColetaDados2 = math.ceil((auxProgresso2 / totalMedidas) * 100)    -- Porcentagem do progresso de coleta de dados
  Parameters.set("ProgressCam2", progressColetaDados2)

  -- Monta tabela para atualizar valores na tabela da tela de visualização
  table.insert(tabelaDados2, 1, {diaTab2=DateTime.getDateTime(), var1Tab2=var1, var2Tab2=var2, var3Tab2=var3})

  -- Controla tamanho máximo da tabela
  if #tabelaDados2 > totalMedidas then
    for i=totalMedidas, #tabelaDados2 do
      table.remove(tabelaDados2, totalMedidas+1)
    end
  end

  local tabelaJson2 = json.encode(tabelaDados2)   -- Converte a tabela em mensagem 'string' para apresentação na tabela do UI
  Script.notifyEvent("enviaDado2", tabelaJson2)
end
Script.serveEvent("SIM_GenericViewer_TCPIPServer.enviaDado2", "enviaDado2")
Script.register("SIM_GenericViewer_TCPIPServer.AtualizaTabela2", registraNaTabela2)
--WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW

--@AltQtdLinhas(change:float):
local function AltQtdLinhas(change)
  totalMedidas = Parameters.get("qtdLinhas")                      -- Carrega total de medidas a serem apresentadas
  Parameters.savePermanent()
end
Script.serveFunction("SIM_GenericViewer_Tabela.AltQtdLinhas", AltQtdLinhas)
