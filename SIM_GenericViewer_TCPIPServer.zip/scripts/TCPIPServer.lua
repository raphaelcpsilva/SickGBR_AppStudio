--Start of Global Scope---------------------------------------------------------
require("dataHora")

Script.serveEvent("SIM_GenericViewer_TCPIPServer.AtualizaTabela1", "AtualizaTabela1")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.AtualizaTabela2", "AtualizaTabela2")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.AtualizaTabela1Calib", "AtualizaTabela1Calib")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.AtualizaTabela2Calib", "AtualizaTabela2Calib")

-- Define nível de brilho inicial do equipamento
local displayConfig = Display.create('DISPLAY1')
displayConfig:setBacklightBrightness(50)

-- Cria objeto de conexão - Servidor TCP/IP
gServer = TCPIPServer.create()

-- Registro dos eventos de controle dos dados pelo Servidor TCP ---------------
TCPIPServer.register(gServer, 'OnConnectionAccepted', 'gHandleConnectionAccepted')  -- Nova conexão no servidor
TCPIPServer.register(gServer, 'OnConnectionClosed', 'gHandleConnectionClosed')      -- Conexão encerrada
TCPIPServer.register(gServer, 'OnReceive', 'gHandleReceive')                        -- Nova mensagem recebida pelo servidor

--End of Global Scope-----------------------------------------------------------

--@atualizaPortaTCPIP(change:float):
local function atualizaPortaTCPIP(change)
  -- Configurações do servidor TCP ----------------------------------------------
  TCPIPServer.setPort(gServer, Parameters.get("portaTCPIP"))    -- Porta de conexão
  TCPIPServer.setFraming(gServer, '\02', '\03', '\02', '\03')             -- Definição de caracteres especiais de inicio/fim de mensagem
  TCPIPServer.listen(gServer)                                             -- Habilita servidor para 'escutar' novas mensagens ou solicitações de conexão (Client)
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.atualizaPortaTCPIP", atualizaPortaTCPIP)
Script.register("Engine.OnStarted", atualizaPortaTCPIP)

-- Variáveis de controle para retransmitir mensagens para CLP
local IDConexCLP = nil
local MSGConex1 = ''
local MSGConex2 = ''
local chegouConex1 = false
local chegouConex2 = false

--Start of Function and Event Scope---------------------------------------------
local handleDisplay = DisplayBrowser.create("BROWSER1")
DisplayBrowser.setHomeURL(handleDisplay, "http://localhost")
DisplayBrowser.setURL(handleDisplay, "http://localhost")

-- Nova conexão no servidor
function gHandleConnectionAccepted(con)
  -- Apresenta mensagem no console sobre nova conexão
  print('Nova conexão iniciada: ' .. con)
  
  -- Verifica qual o IP de origem da conexão
  local IPorigem, port = TCPIPServer.Connection.getPeerAddress(con)
  print(IPorigem, port)

  -- Compara IP para definir câmera atual da conexão
  if IPorigem == Parameters.get("IP_CLP") then
    IDConexCLP = con
  end
end

-- Conexão encerrada
function gHandleConnectionClosed(con)
  -- Apresenta mensagem no console sobre fim de conexão
  print('Conexão encerrada: ' .. con)
  -- Atualiza valor de status da conexão - Encerrada
  Parameters.set("ConAtiva", false)
end

-- Nova mensagem recebida pelo servidor
function gHandleReceive(con, data)
  -- Carrega IP que enviou mensagem
  local IP = TCPIPServer.Connection.getPeerAddress(con)
  -- Apresenta mensagem no console sobre dados recebidos
  print("------------------------------------------------------------")
  print('Recebidos ' .. tostring(#data) .. ' bytes do IP: ' .. IP .. ' ID da conexão ' .. con)
  print('Mensagem recebida: '.. data)

  -- Carrega IPs das câmeras cadastrados na interface para comparação
  local IPCam1 = Parameters.get("IP_CAM1")
  local IPCam2 = Parameters.get("IP_CAM2")

  -- Verifica primeiro caracter da mensagem - JOB ID
  local primCaracter = string.sub(data, 1, 1)

  -- Testa se câmera está em modo de produção
  if primCaracter == tostring(Parameters.get("JobProdID")) then

    -- Se dado veio da câmera 1
    if IP == IPCam1 then
      -- Declara variáveis iniciais
      local var1cam1 = '0'
      local var2cam1 = '0'
      local var3cam1 = '0'

      -- Apresenta mensagem completa na interface
      Parameters.set("MSG_FULL_CAM1", data)

      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
      -- Identifica posição inicial e final da variável 1 na string
      local _, var1cam1ini = string.find(data, Parameters.get("VAR1_INI_CAM1"))
      local var1cam1fim, _ = string.find(data, Parameters.get("VAR1_FIM_CAM1"))
      -- Verifica se foram encontrados os marcadores da string
      if var1cam1ini and var1cam1fim then
        -- Aplica offset da posição inicial/final da variável
        var1cam1ini = var1cam1ini + 1
        var1cam1fim = var1cam1fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var1cam1ini <= var1cam1fim then
          -- Carrega valor da variável 1
          var1cam1 = string.sub(data, var1cam1ini, var1cam1fim)
        end
      end

      -- Verifica se medida está dentro dos limites
      local var1cam1stat = 0                                       -- Variável de status da medida (OK/NOK)
      local int_var1cam1 = tonumber(var1cam1)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var1cam1 == nil or int_var1cam1 == 0 then
        var1cam1 = "0"
      else 
        int_var1cam1 = int_var1cam1 + Parameters.get("OffsetCam1v1")          -- Adiciona valor de Offset definido na IHM
        var1cam1 = tostring(int_var1cam1)                                   -- Converte para string para atualização da tabela
      end
      -- Testa limites
      if int_var1cam1 and int_var1cam1 >= Parameters.get("VAR1_MIN_CAM1") and int_var1cam1 <= Parameters.get("VAR1_MAX_CAM1") then
        var1cam1stat = 1                                          -- Se fora dos limites define variável de status para FALSE
      end
      
      -- *********************************************************************

      -- Identifica posição inicial e final da variável 2 na string
      local _, var2cam1ini = string.find(data, Parameters.get("VAR2_INI_CAM1"))
      local var2cam1fim, _ = string.find(data, Parameters.get("VAR2_FIM_CAM1"))
      -- Verifica se foram encontrados os marcadores da string
      if var2cam1ini and var2cam1fim then
        -- Aplica offset da posição inicial/final da variável
        var2cam1ini = var2cam1ini + 1
        var2cam1fim = var2cam1fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var2cam1ini <= var2cam1fim then
          -- Carrega valor da variável 1
          var2cam1 = string.sub(data, var2cam1ini, var2cam1fim)
        end
      end

      -- Verifica se medida está dentro dos limites
      local var2cam1stat = 0                                       -- Variável de status da medida (OK/NOK)
      local int_var2cam1 = tonumber(var2cam1)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var2cam1 == nil or int_var2cam1 == 0 then
        var2cam1 = "0"
      else 
        int_var2cam1 = int_var2cam1 + Parameters.get("OffsetCam1v2")          -- Adiciona valor de Offset definido na IHM
        var2cam1 = tostring(int_var2cam1)                                   -- Converte para string para atualização da tabela
      end
      -- Testa limites
      if int_var2cam1 and int_var2cam1 >= Parameters.get("VAR2_MIN_CAM1") and int_var2cam1 <= Parameters.get("VAR2_MAX_CAM1") then
        var2cam1stat = 1                                          -- Se fora dos limites define variável de status para FALSE
      end

      -- *********************************************************************

      -- Identifica posição inicial e final da variável 3 na string
      local _, var3cam1ini = string.find(data, Parameters.get("VAR3_INI_CAM1"))
      local var3cam1fim, _ = string.find(data, Parameters.get("VAR3_FIM_CAM1"))
      -- Verifica se foram encontrados os marcadores da string
      if var3cam1ini and var3cam1fim then
        -- Aplica offset da posição inicial/final da variável
        var3cam1ini = var3cam1ini + 1
        var3cam1fim = var3cam1fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var3cam1ini <= var3cam1fim then
          -- Carrega valor da variável 1
          var3cam1 = string.sub(data, var3cam1ini, var3cam1fim)
        end
      end

      -- Verifica se medida está dentro dos limites
      local var3cam1stat = 0                                       -- Variável de status da medida (OK/NOK)
      local int_var3cam1 = tonumber(var3cam1)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var3cam1 == nil or int_var3cam1 == 0 then
        var3cam1 = "0"
      else 
        int_var3cam1 = int_var3cam1 + Parameters.get("OffsetCam1v3")          -- Adiciona valor de Offset definido na IHM
        var3cam1 = tostring(int_var3cam1)                                   -- Converte para string para atualização da tabela
      end
      -- Testa limites
      if int_var3cam1 and int_var3cam1 >= Parameters.get("VAR3_MIN_CAM1") and int_var3cam1 <= Parameters.get("VAR3_MAX_CAM1") then
        var3cam1stat = 1                                          -- Se fora dos limites define variável de status para FALSE
      end
      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

      -- Atualiza resultado CAM1 na interface
      Parameters.set("VAR1_RES_CAM1", var1cam1)
      Parameters.set("STATUS_VAR1_CAM1", var1cam1stat)
      Parameters.set("VAR2_RES_CAM1", var2cam1)
      Parameters.set("STATUS_VAR2_CAM1", var2cam1stat)
      Parameters.set("VAR3_RES_CAM1", var3cam1)
      Parameters.set("STATUS_VAR3_CAM1", var3cam1stat)

      -- Registra valores na tabela
      Script.notifyEvent("AtualizaTabela1", var1cam1, var2cam1, var3cam1)

      -- Compila nome da câmera + mensagem completa para enviar ao CLP
      MSGConex1 = Parameters.get("NOME_CAM1")..Parameters.get("JobProdID")..
                  Parameters.get("VAR1_INI_CAM1")..var1cam1..Parameters.get("VAR1_FIM_CAM1")..
                  Parameters.get("VAR2_INI_CAM1")..var2cam1..Parameters.get("VAR2_FIM_CAM1")..
                  Parameters.get("VAR3_INI_CAM1")..var3cam1..Parameters.get("VAR3_FIM_CAM1")
      chegouConex1 = true

      -- Rotina limpa status teste conexão
      local difHoraTesteCam1 = DateTime.getTimestamp() - horaTesteCam1
      if Parameters.get("STATUS_CAM1") ~= "pending" and difHoraTesteCam1 > 5000 then
        Parameters.set("STATUS_CAM1", "pending")
      end
    end

    --§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
    --§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§
    -- Se dado veio da câmera 2
    if IP == IPCam2 then
      -- Declara variáveis iniciais
      local var1cam2 = '0'
      local var2cam2 = '0'
      local var3cam2 = '0'

      -- Apresenta mensagem completa na interface
      Parameters.set("MSG_FULL_CAM2", data)

      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
      -- Identifica posição inicial e final da variável 1 na string
      local _, var1cam2ini = string.find(data, Parameters.get("VAR1_INI_CAM2"))
      local var1cam2fim, _ = string.find(data, Parameters.get("VAR1_FIM_CAM2"))
      -- Verifica se foram encontrados os marcadores da string
      if var1cam2ini and var1cam2fim then
        -- Aplica offset da posição inicial/final da variável
        var1cam2ini = var1cam2ini + 1
        var1cam2fim = var1cam2fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var1cam2ini <= var1cam2fim then
          -- Carrega valor da variável 1
          var1cam2 = string.sub(data, var1cam2ini, var1cam2fim)
        end
      end

      -- Verifica se medida está dentro dos limites
      local var1cam2stat = 0                                       -- Variável de status da medida (OK/NOK)
      local int_var1cam2 = tonumber(var1cam2)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var1cam2 == nil or int_var1cam2 == 0 then
        var1cam2 = "0"
      else 
        int_var1cam2 = int_var1cam2 + Parameters.get("OffsetCam2v1")          -- Adiciona valor de Offset definido na IHM
        var1cam2 = tostring(int_var1cam2)                                   -- Converte para string para atualização da tabela
      end
      -- Testa limites
      if int_var1cam2 and int_var1cam2 >= Parameters.get("VAR1_MIN_CAM2") and int_var1cam2 <= Parameters.get("VAR1_MAX_CAM2") then
        var1cam2stat = 1                                          -- Se fora dos limites define variável de status para FALSE
      end
      
      -- *********************************************************************

      -- Identifica posição inicial e final da variável 2 na string
      local _, var2cam2ini = string.find(data, Parameters.get("VAR2_INI_CAM2"))
      local var2cam2fim, _ = string.find(data, Parameters.get("VAR2_FIM_CAM2"))
      -- Verifica se foram encontrados os marcadores da string
      if var2cam2ini and var2cam2fim then
        -- Aplica offset da posição inicial/final da variável
        var2cam2ini = var2cam2ini + 1
        var2cam2fim = var2cam2fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var2cam2ini <= var2cam2fim then
          -- Carrega valor da variável 1
          var2cam2 = string.sub(data, var2cam2ini, var2cam2fim)
        end
      end

      -- Verifica se medida está dentro dos limites
      local var2cam2stat = 0                                       -- Variável de status da medida (OK/NOK)
      local int_var2cam2 = tonumber(var2cam2)                         -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var2cam2 == nil or int_var2cam2 == 0 then
        var2cam2 = "0"
      else 
        int_var2cam2 = int_var2cam2 + Parameters.get("OffsetCam2v2")          -- Adiciona valor de Offset definido na IHM
        var2cam2 = tostring(int_var2cam2)                                   -- Converte para string para atualização da tabela
      end
      -- Testa limites
      if int_var2cam2 and int_var2cam2 >= Parameters.get("VAR2_MIN_CAM2") and int_var2cam2 <= Parameters.get("VAR2_MAX_CAM2") then
        var2cam2stat = 1                                          -- Se fora dos limites define variável de status para FALSE
      end
      
      -- *********************************************************************

      -- Identifica posição inicial e final da variável 3 na string
      local _, var3cam2ini = string.find(data, Parameters.get("VAR3_INI_CAM2"))
      local var3cam2fim, _ = string.find(data, Parameters.get("VAR3_FIM_CAM2"))
      -- Verifica se foram encontrados os marcadores da string
      if var3cam2ini and var3cam2fim then
        -- Aplica offset da posição inicial/final da variável
        var3cam2ini = var3cam2ini + 1
        var3cam2fim = var3cam2fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var3cam2ini <= var3cam2fim then
          -- Carrega valor da variável 1
          var3cam2 = string.sub(data, var3cam2ini, var3cam2fim)
        end
      end

      -- Verifica se medida está dentro dos limites
      local var3cam2stat = 0                                       -- Variável de status da medida (OK/NOK)
      local int_var3cam2 = tonumber(var3cam2)                         -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var3cam2 == nil or int_var3cam2 == 0 then
        var3cam2 = "0"
      else 
        int_var3cam2 = int_var3cam2 + Parameters.get("OffsetCam2v3")          -- Adiciona valor de Offset definido na IHM
        var3cam2 = tostring(int_var3cam2)                                   -- Converte para string para atualização da tabela
      end
      -- Testa limites
      if int_var3cam2 and int_var3cam2 >= Parameters.get("VAR3_MIN_CAM2") and int_var3cam2 <= Parameters.get("VAR3_MAX_CAM2") then
        var3cam2stat = 1                                          -- Se fora dos limites define variável de status para FALSE
      end
      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

      -- Atualiza resultado CAM2 na interface
      Parameters.set("VAR1_RES_CAM2", var1cam2)
      Parameters.set("STATUS_VAR1_CAM2", var1cam2stat)
      Parameters.set("VAR2_RES_CAM2", var2cam2)
      Parameters.set("STATUS_VAR2_CAM2", var2cam2stat)
      Parameters.set("VAR3_RES_CAM2", var3cam2)
      Parameters.set("STATUS_VAR3_CAM2", var3cam2stat)

      -- Registra valores na tabela
      Script.notifyEvent("AtualizaTabela2", var1cam2, var2cam2, var3cam2)

      -- Compila nome da câmera + mensagem completa para enviar ao CLP
      MSGConex2 = Parameters.get("NOME_CAM2")..Parameters.get("JobProdID")..
                  Parameters.get("VAR1_INI_CAM2")..var1cam2..Parameters.get("VAR1_FIM_CAM2")..
                  Parameters.get("VAR2_INI_CAM2")..var2cam2..Parameters.get("VAR2_FIM_CAM2")..
                  Parameters.get("VAR3_INI_CAM2")..var3cam2..Parameters.get("VAR3_FIM_CAM2")
      chegouConex2 = true

      -- Rotina limpa status teste conexão
      local difHoraTesteCam2 = DateTime.getTimestamp() - horaTesteCam2
      if Parameters.get("STATUS_CAM2") ~= "pending" and difHoraTesteCam2 > 5000 then
        Parameters.set("STATUS_CAM2", "pending")
      end
    end

  -- Testa se câmera está em modo de produção
  elseif primCaracter == tostring(Parameters.get("JobCalibID")) then
    -- Se dado veio da câmera 1
    if IP == IPCam1 then
      -- Declara variáveis iniciais
      local var1cam1 = '0'
      local var2cam1 = '0'
      local var3cam1 = '0'

      -- Apresenta mensagem completa na interface
      Parameters.set("MSG_FULL_CAM1", data)

      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
      -- Identifica posição inicial e final da variável 1 na string
      local _, var1cam1ini = string.find(data, Parameters.get("VAR1_INI_CAM1"))
      local var1cam1fim, _ = string.find(data, Parameters.get("VAR1_FIM_CAM1"))
      -- Verifica se foram encontrados os marcadores da string
      if var1cam1ini and var1cam1fim then
        -- Aplica offset da posição inicial/final da variável
        var1cam1ini = var1cam1ini + 1
        var1cam1fim = var1cam1fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var1cam1ini <= var1cam1fim then
          -- Carrega valor da variável 1
          var1cam1 = string.sub(data, var1cam1ini, var1cam1fim)
        end
      end

      local int_var1cam1 = tonumber(var1cam1)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var1cam1 == nil or int_var1cam1 == 0 then
        var1cam1 = "0"
      else 
        int_var1cam1 = int_var1cam1 + Parameters.get("OffsetCam1v1")          -- Adiciona valor de Offset definido na IHM
        var1cam1 = tostring(int_var1cam1)                                   -- Converte para string para atualização da tabela
      end
      
      -- *********************************************************************

      -- Identifica posição inicial e final da variável 2 na string
      local _, var2cam1ini = string.find(data, Parameters.get("VAR2_INI_CAM1"))
      local var2cam1fim, _ = string.find(data, Parameters.get("VAR2_FIM_CAM1"))
      -- Verifica se foram encontrados os marcadores da string
      if var2cam1ini and var2cam1fim then
        -- Aplica offset da posição inicial/final da variável
        var2cam1ini = var2cam1ini + 1
        var2cam1fim = var2cam1fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var2cam1ini <= var2cam1fim then
          -- Carrega valor da variável 1
          var2cam1 = string.sub(data, var2cam1ini, var2cam1fim)
        end
      end

      local int_var2cam1 = tonumber(var2cam1)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var2cam1 == nil or int_var2cam1 == 0 then
        var2cam1 = "0"
      else 
        int_var2cam1 = int_var2cam1 + Parameters.get("OffsetCam1v2")          -- Adiciona valor de Offset definido na IHM
        var2cam1 = tostring(int_var2cam1)                                   -- Converte para string para atualização da tabela
      end

      -- *********************************************************************

      -- Identifica posição inicial e final da variável 3 na string
      local _, var3cam1ini = string.find(data, Parameters.get("VAR3_INI_CAM1"))
      local var3cam1fim, _ = string.find(data, Parameters.get("VAR3_FIM_CAM1"))
      -- Verifica se foram encontrados os marcadores da string
      if var3cam1ini and var3cam1fim then
        -- Aplica offset da posição inicial/final da variável
        var3cam1ini = var3cam1ini + 1
        var3cam1fim = var3cam1fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var3cam1ini <= var3cam1fim then
          -- Carrega valor da variável 1
          var3cam1 = string.sub(data, var3cam1ini, var3cam1fim)
        end
      end

      local int_var3cam1 = tonumber(var3cam1)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var3cam1 == nil or int_var3cam1 == 0 then
        var3cam1 = "0"
      else 
        int_var3cam1 = int_var3cam1 + Parameters.get("OffsetCam1v3")          -- Adiciona valor de Offset definido na IHM
        var3cam1 = tostring(int_var3cam1)                                   -- Converte para string para atualização da tabela
      end
      
      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

      -- Atualiza resultado CAM1 na interface
      Parameters.set("VAR1_RES_CAM1", var1cam1)
      Parameters.set("STATUS_VAR1_CAM1", 2)
      Parameters.set("VAR2_RES_CAM1", var2cam1)
      Parameters.set("STATUS_VAR2_CAM1", 2)
      Parameters.set("VAR3_RES_CAM1", var3cam1)
      Parameters.set("STATUS_VAR3_CAM1", 2)

      -- Registra valores na tabela
      Script.notifyEvent("AtualizaTabela1Calib", var1cam1, var2cam1, var3cam1)

      -- Compila nome da câmera + mensagem completa para enviar ao CLP
      MSGConex1 = Parameters.get("NOME_CAM1")..Parameters.get("JobCalibID")..
                  Parameters.get("VAR1_INI_CAM1")..var1cam1..Parameters.get("VAR1_FIM_CAM1")..
                  Parameters.get("VAR2_INI_CAM1")..var2cam1..Parameters.get("VAR2_FIM_CAM1")..
                  Parameters.get("VAR3_INI_CAM1")..var3cam1..Parameters.get("VAR3_FIM_CAM1")
      chegouConex1 = true

      -- Rotina limpa status teste conexão
      local difHoraTesteCam1 = DateTime.getTimestamp() - horaTesteCam1
      if Parameters.get("STATUS_CAM1") ~= "pending" and difHoraTesteCam1 > 5000 then
        Parameters.set("STATUS_CAM1", "pending")
      end
    end

    -- Se dado veio da câmera 2
    if IP == IPCam2 then
      -- Declara variáveis iniciais
      local var1cam2 = '0'
      local var2cam2 = '0'
      local var3cam2 = '0'

      -- Apresenta mensagem completa na interface
      Parameters.set("MSG_FULL_CAM2", data)

      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
      -- Identifica posição inicial e final da variável 1 na string
      local _, var1cam2ini = string.find(data, Parameters.get("VAR1_INI_CAM2"))
      local var1cam2fim, _ = string.find(data, Parameters.get("VAR1_FIM_CAM2"))
      -- Verifica se foram encontrados os marcadores da string
      if var1cam2ini and var1cam2fim then
        -- Aplica offset da posição inicial/final da variável
        var1cam2ini = var1cam2ini + 1
        var1cam2fim = var1cam2fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var1cam2ini <= var1cam2fim then
          -- Carrega valor da variável 1
          var1cam2 = string.sub(data, var1cam2ini, var1cam2fim)
        end
      end

      local int_var1cam2 = tonumber(var1cam2)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var1cam2 == nil or int_var1cam2 == 0 then
        var1cam2 = "0"
      else 
        int_var1cam2 = int_var1cam2 + Parameters.get("OffsetCam2v1")          -- Adiciona valor de Offset definido na IHM
        var1cam2 = tostring(int_var1cam2)                                   -- Converte para string para atualização da tabela
      end
      
      -- *********************************************************************

      -- Identifica posição inicial e final da variável 2 na string
      local _, var2cam2ini = string.find(data, Parameters.get("VAR2_INI_CAM2"))
      local var2cam2fim, _ = string.find(data, Parameters.get("VAR2_FIM_CAM2"))
      -- Verifica se foram encontrados os marcadores da string
      if var2cam2ini and var2cam2fim then
        -- Aplica offset da posição inicial/final da variável
        var2cam2ini = var2cam2ini + 1
        var2cam2fim = var2cam2fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var2cam2ini <= var2cam2fim then
          -- Carrega valor da variável 1
          var2cam2 = string.sub(data, var2cam2ini, var2cam2fim)
        end
      end

      local int_var2cam2 = tonumber(var2cam2)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var2cam2 == nil or int_var2cam2 == 0 then
        var2cam2 = "0"
      else 
        int_var2cam2 = int_var2cam2 + Parameters.get("OffsetCam2v2")          -- Adiciona valor de Offset definido na IHM
        var2cam2 = tostring(int_var2cam2)                                   -- Converte para string para atualização da tabela
      end

      -- *********************************************************************

      -- Identifica posição inicial e final da variável 3 na string
      local _, var3cam2ini = string.find(data, Parameters.get("VAR3_INI_CAM2"))
      local var3cam2fim, _ = string.find(data, Parameters.get("VAR3_FIM_CAM2"))
      -- Verifica se foram encontrados os marcadores da string
      if var3cam2ini and var3cam2fim then
        -- Aplica offset da posição inicial/final da variável
        var3cam2ini = var3cam2ini + 1
        var3cam2fim = var3cam2fim - 1
        -- Verifica se valor da variável é 'vazio'
        if var3cam2ini <= var3cam2fim then
          -- Carrega valor da variável 1
          var3cam2 = string.sub(data, var3cam2ini, var3cam2fim)
        end
      end

      local int_var3cam2 = tonumber(var3cam2)                      -- Converte valor da medida de string para número
      -- Se não for possível converter para número (nil), define "0" para o resultado da medida
      if int_var3cam2 == nil or int_var3cam2 == 0 then
        var3cam2 = "0"
      else 
        int_var3cam2 = int_var3cam2 + Parameters.get("OffsetCam2v3")          -- Adiciona valor de Offset definido na IHM
        var3cam2 = tostring(int_var3cam2)                                   -- Converte para string para atualização da tabela
      end
      
      -- &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

      -- Atualiza resultado CAM2 na interface
      Parameters.set("VAR1_RES_CAM2", var1cam2)
      Parameters.set("STATUS_VAR1_CAM2", 2)
      Parameters.set("VAR2_RES_CAM2", var2cam2)
      Parameters.set("STATUS_VAR2_CAM2", 2)
      Parameters.set("VAR3_RES_CAM2", var3cam2)
      Parameters.set("STATUS_VAR3_CAM2", 2)

      -- Registra valores na tabela
      Script.notifyEvent("AtualizaTabela2Calib", var1cam2, var2cam2, var3cam2)

      -- Compila nome da câmera + mensagem completa para enviar ao CLP
      MSGConex2 = Parameters.get("NOME_CAM2")..Parameters.get("JobCalibID")..
                  Parameters.get("VAR1_INI_CAM2")..var1cam2..Parameters.get("VAR1_FIM_CAM2")..
                  Parameters.get("VAR2_INI_CAM2")..var2cam2..Parameters.get("VAR2_FIM_CAM2")..
                  Parameters.get("VAR3_INI_CAM2")..var3cam2..Parameters.get("VAR3_FIM_CAM2")
      chegouConex2 = true

      -- Rotina limpa status teste conexão
      local difHoraTesteCam2 = DateTime.getTimestamp() - horaTesteCam2
      if Parameters.get("STATUS_CAM2") ~= "pending" and difHoraTesteCam2 > 5000 then
        Parameters.set("STATUS_CAM2", "pending")
      end
    end
  end

  -- Verifica se tem mensagem pronta para enviar para o CLP
  if chegouConex1 and chegouConex2 then
    -- Atualiza valor na interface
    local MSGCompleta1e2 = MSGConex1 .. MSGConex2
    Parameters.set("MSG_FULL_CLP", MSGCompleta1e2)
    
    if IDConexCLP and TCPIPServer.Connection.isConnected(IDConexCLP) then
      TCPIPServer.Connection.transmit(IDConexCLP, MSGCompleta1e2)

      -- Limpa memórias para próxima mensagem
      chegouConex1 = false
      chegouConex2 = false
    else
      print("CLP Desconectado")
    end
  end

  -- Rotina limpa status teste conexão
  local difHoraTesteCLP = DateTime.getTimestamp() - horaTesteCLP
  if Parameters.get("STATUS_CLP") ~= "pending" and difHoraTesteCLP > 5000 then
    Parameters.set("STATUS_CLP", "pending")
  end
end

-- #############################################################################
--  Teste de ping câmera 1
horaTesteCam1 = 0           -- Variável auxiliar de hora do teste de ping
local function testeConexCam1()
  -- Indica que teste de conexão começou
  print("Teste Conexão - Câmera 1")
  -- Carrega IP da câmera e envia o ping
  local camIP = Parameters.get("IP_CAM1")
  -- Teste de ping com o dispositivo
  local pingStatus = Ethernet.ping(camIP, 1000)
  -- Atualiza ícone na tela sobre status da conexão
  if pingStatus then
    Parameters.set("STATUS_CAM1", "success")
    print("Teste de Conexão OK - Câmera 1")
  else
    Parameters.set("STATUS_CAM1", "error")
    print("Teste de Conexão NOK - Câmera 1")
  end
  horaTesteCam1 = DateTime.getTimestamp()
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.testeConexCam1", testeConexCam1)

-- #############################################################################
--  Teste de ping câmera 2
horaTesteCam2 = 0           -- Variável auxiliar de hora do teste de ping
local function testeConexCam2()
  -- Indica que teste de conexão começou
  print("Teste Conexão - Câmera 2")
  -- Carrega IP da câmera e envia o ping
  local camIP = Parameters.get("IP_CAM2")
  -- Teste de ping com o dispositivo
  local pingStatus = Ethernet.ping(camIP, 1000)
  -- Atualiza ícone na tela sobre status da conexão
  if pingStatus then
    Parameters.set("STATUS_CAM2", "success")
    print("Teste de Conexão OK - Câmera 2")
  else
    Parameters.set("STATUS_CAM2", "error")
    print("Teste de Conexão NOK - Câmera 2")
  end
  horaTesteCam2 = DateTime.getTimestamp()
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.testeConexCam2", testeConexCam2)

-- #############################################################################
--  Teste de ping CLP
horaTesteCLP = 0           -- Variável auxiliar de hora do teste de ping
local function testeConexCLP()
  -- Indica que teste de conexão começou
  print("Teste Conexão - CLP")
  -- Carrega IP da câmera e envia o ping
  local clpIP = Parameters.get("IP_CLP")
  -- Teste de ping com o dispositivo
  local pingStatus = Ethernet.ping(clpIP, 1000)
  -- Atualiza ícone na tela sobre status da conexão
  if pingStatus then
    Parameters.set("STATUS_CLP", "success")
    print("Teste de Conexão OK - CLP")
  else
    Parameters.set("STATUS_CLP", "error")
    print("Teste de Conexão NOK - CLP")
  end
  horaTesteCLP = DateTime.getTimestamp()
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.testeConexCLP", testeConexCLP)

--@salvaParametros():
local function salvaParametros()
  -- Salva parâmetros de forma permanente
  Parameters.savePermanent()
  print("Parâmetros salvos com sucesso!")
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.salvaParametros", salvaParametros)


-- Copia valores de limite da conexão 1 para a conexão 2
--@copiaLim1p2():
local function copiaLim1p2()
  print("Copiando valores de limites Câmera 1 => câmera 2")

  local v1c1min = Parameters.get("VAR1_MIN_CAM1")
  local v1c1max = Parameters.get("VAR1_MAX_CAM1")
  local v2c1min = Parameters.get("VAR2_MIN_CAM1")
  local v2c1max = Parameters.get("VAR2_MAX_CAM1")
  local v3c1min = Parameters.get("VAR3_MIN_CAM1")
  local v3c1max = Parameters.get("VAR3_MAX_CAM1")

  Parameters.set("VAR1_MIN_CAM2", v1c1min)
  Parameters.set("VAR1_MAX_CAM2", v1c1max)
  Parameters.set("VAR2_MIN_CAM2", v2c1min)
  Parameters.set("VAR2_MAX_CAM2", v2c1max)
  Parameters.set("VAR3_MIN_CAM2", v3c1min)
  Parameters.set("VAR3_MAX_CAM2", v3c1max)

  Script.notifyEvent("v1c2min", v1c1min)
  Script.notifyEvent("v1c2max", v1c1max)
  Script.notifyEvent("v2c2min", v2c1min)
  Script.notifyEvent("v2c2max", v2c1max)
  Script.notifyEvent("v3c2min", v3c1min)
  Script.notifyEvent("v3c2max", v3c1max)
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.copiaLim1p2", copiaLim1p2)

Script.serveEvent("SIM_GenericViewer_TCPIPServer.v1c2min", "v1c2min")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v1c2max", "v1c2max")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v2c2min", "v2c2min")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v2c2max", "v2c2max")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v3c2min", "v3c2min")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v3c2max", "v3c2max")

-- Copia valores de limite da conexão 2 para a conexão 1
--@copiaLim2p1():
local function copiaLim2p1()
  print("Copiando valores de limites Câmera 2 => câmera 1")
  
  local v1c2min = Parameters.get("VAR1_MIN_CAM2")
  local v1c2max = Parameters.get("VAR1_MAX_CAM2")
  local v2c2min = Parameters.get("VAR2_MIN_CAM2")
  local v2c2max = Parameters.get("VAR2_MAX_CAM2")
  local v3c2min = Parameters.get("VAR3_MIN_CAM2")
  local v3c2max = Parameters.get("VAR3_MAX_CAM2")

  Parameters.set("VAR1_MIN_CAM1", v1c2min)
  Parameters.set("VAR1_MAX_CAM1", v1c2max)
  Parameters.set("VAR2_MIN_CAM1", v2c2min)
  Parameters.set("VAR2_MAX_CAM1", v2c2max)
  Parameters.set("VAR3_MIN_CAM1", v3c2min)
  Parameters.set("VAR3_MAX_CAM1", v3c2max)

  Script.notifyEvent("v1c1min", v1c2min)
  Script.notifyEvent("v1c1max", v1c2max)
  Script.notifyEvent("v2c1min", v2c2min)
  Script.notifyEvent("v2c1max", v2c2max)
  Script.notifyEvent("v3c1min", v3c2min)
  Script.notifyEvent("v3c1max", v3c2max)
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.copiaLim2p1", copiaLim2p1)

Script.serveEvent("SIM_GenericViewer_TCPIPServer.v1c1min", "v1c1min")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v1c1max", "v1c1max")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v2c1min", "v2c1min")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v2c1max", "v2c1max")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v3c1min", "v3c1min")
Script.serveEvent("SIM_GenericViewer_TCPIPServer.v3c1max", "v3c1max")
