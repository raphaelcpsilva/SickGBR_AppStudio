
--@puxaDataHora():string
local function puxaDataHora()
  local value = DateTime.getDateTime()          -- Carrega Data e Hora atual do equipamento
  local comp = string.len(value)                -- Verifica comprimento total da string com a data e hora
  local semMS = string.sub(value,1,comp-4)      -- Elimina os caracteres de milisegundos da string ".000"

  return semMS                                  -- Retorna string completa sem os milisegundos
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.puxaDataHora", puxaDataHora)



--@AtualizaHora():
local function AtualizaHora()
  print("Botão atualiza Hora")

  -- Carrega novos valores de data/hora
  local dia = Parameters.get("Dia")
  local mes = Parameters.get("Mes")
  local ano = Parameters.get("Ano")
  local hora = Parameters.get("Hora")
  local minuto = Parameters.get("Minuto")

  -- Aplica nova data no equipamento
  DateTime.setDateTime(ano, mes, dia, hora, minuto, 0, false)
  print("Nova data definida: "..DateTime.getDateTime())
  
end
Script.serveFunction("SIM_GenericViewer_TCPIPServer.AtualizaHora", AtualizaHora)
